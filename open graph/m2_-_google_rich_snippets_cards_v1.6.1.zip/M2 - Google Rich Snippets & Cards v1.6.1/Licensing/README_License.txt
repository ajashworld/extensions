This Magento extension is comprised of two parts: 

(1) The PHP code and integrated HTML are licensed under the OSL-3.0 license as is Magento itself.  You will find a copy of the license text in the same directory as this text file. Or you can read it here: http://opensource.org/licenses/osl-3.0.php linking fromhttp://www.magentocommerce.com/license/ 

(2) All other parts of the theme including, but not limited to the CSS code, images, and design are licensed according to the license purchased. 